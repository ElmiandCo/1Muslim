import "./globals.css";

export const metadata = {
  title: "OneMuslim — Community, Knowledge, Media & Commerce",
  description: "A connected Muslim platform for community, learning, streaming, and commerce."
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
