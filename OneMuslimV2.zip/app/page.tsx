 "use client";

import { useState } from "react";

const nav = ["Home", "Stream", "Lessons", "Community", "Shop", "Connect", "Profile"];

const cards = [
  { icon: "◉", title: "Watch Live", text: "Discover live conversations, classes, reminders and community streams.", action: "Watch streams" },
  { icon: "✦", title: "Learn & Earn XP", text: "Watch lessons, answer questions and build your rank.", action: "Explore lessons" },
  { icon: "⌁", title: "Communities", text: "Find people around shared interests, knowledge and causes.", action: "Browse communities" },
  { icon: "◇", title: "OneMuslim Shop", text: "Discover products from the community or open your own storefront.", action: "Open shop" },
  { icon: "◎", title: "Connect", text: "Bring your social presence together with one reusable connector system.", action: "Manage connections" },
  { icon: "◌", title: "Your Progress", text: "XP, ranks, achievements and unlockable profile customization.", action: "View profile" }
];

export default function Home() {
  const [signedIn, setSignedIn] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [active, setActive] = useState("Home");

  function signIn(e: React.FormEvent) {
    e.preventDefault();
    if (email.trim() && password.trim()) setSignedIn(true);
  }

  return (
    <main className="shell">
      <header className="topbar">
        <div className="brand">
          <div className="brand-mark">☾</div>
          <div>
            <strong>OneMuslim</strong>
            <span>Knowledge • Community • Connection</span>
          </div>
        </div>
        <nav className="nav">
          {nav.map(item => (
            <button className={active === item ? "nav-link active" : "nav-link"} key={item} onClick={() => setActive(item)}>
              {item}
            </button>
          ))}
        </nav>
        <button className="profile-pill" onClick={() => setActive("Profile")}>
          <span className="avatar">OM</span>
          {signedIn ? "My profile" : "Guest"}
        </button>
      </header>

      <section className="hero">
        <div className="hero-glow" />
        <div className="hero-copy">
          <p className="eyebrow">ONE CONNECTED UMMAH</p>
          <h1>One place to <span>learn, connect, create & grow.</span></h1>
          <p className="hero-text">
            A modern Muslim platform bringing community, knowledge, livestreams,
            progression and commerce into one beautiful experience.
          </p>
          <div className="hero-actions">
            <button className="primary" onClick={() => document.getElementById("explore")?.scrollIntoView({ behavior: "smooth" })}>Explore OneMuslim</button>
            <button className="secondary" onClick={() => setActive("Stream")}>Watch live</button>
          </div>
          <div className="hero-stats">
            <div><b>01</b><span>Learn</span></div>
            <div><b>02</b><span>Connect</span></div>
            <div><b>03</b><span>Create</span></div>
            <div><b>04</b><span>Grow</span></div>
          </div>
        </div>

        <div className="orbital">
          <div className="orbit orbit-one" />
          <div className="orbit orbit-two" />
          <div className="orb-core">
            <div className="crescent">☾</div>
            <strong>ONE</strong>
            <span>MUSLIM</span>
          </div>
        </div>
      </section>

      {!signedIn && (
        <section className="auth-card">
          <div>
            <p className="eyebrow">DEMO ACCESS</p>
            <h2>Enter OneMuslim</h2>
            <p>Demo authentication is enabled now. Supabase can be connected without rebuilding the experience.</p>
          </div>
          <form onSubmit={signIn}>
            <input value={email} onChange={e => setEmail(e.target.value)} placeholder="Email" type="email" required />
            <input value={password} onChange={e => setPassword(e.target.value)} placeholder="Password" type="password" required />
            <button className="primary" type="submit">Sign in</button>
          </form>
        </section>
      )}

      {signedIn && (
        <section className="welcome-strip">
          <div><span className="live-dot" /> Signed in</div>
          <strong>Welcome to OneMuslim.</strong>
          <button onClick={() => setSignedIn(false)}>Sign out</button>
        </section>
      )}

      <section id="explore" className="section">
        <div className="section-heading">
          <div>
            <p className="eyebrow">THE PLATFORM</p>
            <h2>Everything has a place.</h2>
          </div>
          <p>Create it. View it. Join it. Build your presence.</p>
        </div>
        <div className="grid">
          {cards.map(card => (
            <article className="feature-card" key={card.title}>
              <div className="card-icon">{card.icon}</div>
              <h3>{card.title}</h3>
              <p>{card.text}</p>
              <button onClick={() => setActive(card.title.includes("Live") ? "Stream" : card.title.includes("Lesson") ? "Lessons" : card.title.includes("Shop") ? "Shop" : card.title.includes("Connect") ? "Connect" : card.title.includes("Commun") ? "Community" : "Profile")}>{card.action} <span>→</span></button>
            </article>
          ))}
        </div>
      </section>

      <section className="live-preview">
        <div>
          <p className="eyebrow">STREAM • LIVE</p>
          <h2>Go Live or watch what is happening now.</h2>
          <p>Streaming is a first-class part of OneMuslim. Topics, categories, viewers, chat, profiles and creator tools are designed into the platform.</p>
        </div>
        <div className="stream-card">
          <div className="stream-thumb"><span className="live-badge">LIVE</span><span className="viewer">● 1.2K</span><div className="play">▶</div></div>
          <div className="stream-info"><strong>Knowledge & Community</strong><span>Weekly community discussion</span></div>
        </div>
      </section>

      <footer>
        <strong>OneMuslim</strong>
        <span>Built as a scalable foundation for community, knowledge, media and commerce.</span>
      </footer>
    </main>
  );
}
