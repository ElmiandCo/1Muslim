# OneMuslim — Product Blueprint

This file is the canonical product blueprint for OneMuslim. Future development should refer back to this document before changing architecture, navigation, feature scope, or UX principles.

## Core Product Principle
Every major feature must support both CREATE and VIEW.

Examples:
- Go Live / Watch Live
- Create Post / View Posts
- Create Community / View Communities
- Sell / Shop
- Create Product / View Products
- Create Lesson / View Lessons
- Create Event / View Events
- Connect Account / View Connections
- Create Profile / View Profiles

Do not build pages that are merely static displays.

## Product
OneMuslim is a production-quality Muslim social, learning, streaming, community, and marketplace platform.

## Primary Navigation
- Home
- Stream
- Lessons
- Community
- Shop
- Connect
- Profile

Additional areas:
- Notifications
- Messages
- Search
- Settings
- Creator/Seller Studio

## Visual Direction
- Premium Muslim technology/social aesthetic
- Modern and elegant
- High-tech without looking artificial
- Muslim-inspired without excessive decorative clichés
- Dark-first
- Optional light mode
- Beautiful typography
- Smooth animations
- Subtle gradients
- Glass/card effects where appropriate
- Excellent spacing
- Responsive desktop/tablet/mobile
- Accessible contrast
- Loading, skeleton, empty, error, success, confirmation, toast, and modal states
- Avoid generic AI-generated dashboard aesthetics

## Authentication
Foundation must support:
- Sign in
- Sign up
- Password
- Remember session
- Forgot password
- Account creation
- Protected routes
- User session state
- Sign out
- Profile creation
- Onboarding

Supabase is the intended backend. Initial demo mode may provide convenient development sign-in while preserving a path to real Supabase Auth.

## Home
Include cards for:
- Recommended videos
- Live streams
- Recent posts
- Communities
- Lessons
- Marketplace products
- Featured creators
- Suggested connections
- XP/progression
- Announcements

Posts support:
- Text
- Images
- Video
- Links
- Hashtags
- Topics
- Comments
- Reactions
- Sharing

## Stream
Watch Live:
- Browse/search/filter streams
- Topic/category filtering
- Viewer counts
- Streamer profiles
- Enter stream
- Chat/comment
- Follow
- Share

Go Live:
- Create livestream
- Title/description
- Topic/category
- Thumbnail
- Visibility
- Start/end stream

Use a polished mocked streaming experience initially, with architecture ready for real infrastructure.

## Lessons & XP
Lessons initially contain video content and can include:
- Video
- Title
- Description
- Topic
- Questions
- Answers
- XP reward
- Completion
- Progress

Build a configurable reward engine. Early questions are around 100 XP; rewards progressively increase and can eventually reach approximately 2,000,000 XP per question.

## Gamification
Users have:
- XP
- Rank
- Level
- Progress bar
- Achievements
- Badges
- Unlocks

Profile completion can award XP for:
- Photo
- Bio
- Location/time zone
- Interests
- Social connection
- Lesson completion
- Community participation

## Unlocks
Unlockable:
- Avatars
- Profile backgrounds
- Frames
- Badges
- Themes
- Visual effects
- Creator features
- Streaming privileges

Go Live may unlock at a configurable threshold such as 500 XP.

## Profiles
Show:
- Avatar/background
- Name/username/bio
- XP/rank/level
- Badges/achievements
- Communities
- Posts
- Videos
- Livestream history
- Products
- Connected accounts

## Communities
View:
- Discover/search
- Topics
- Join/leave
- Members
- Posts
- Events

Create:
- Name
- Description
- Category
- Image/banner
- Privacy
- Publish

Community page:
- Feed
- Members
- About
- Events
- Media
- Moderation controls

## Marketplace / Shop
Shop:
- Browse/search/filter/sort
- Product details
- Cart
- Checkout
- Orders

Sell:
- Create/edit/delete product
- Images
- Title/description
- Price
- Category
- Inventory
- Shipping
- Condition
- Publish/unpublish

Prepare for Stripe. Never fake successful real payments.

## Advertising
Support:
- Sponsored products
- Featured products
- Promotional cards
- Seller advertisements

Data model:
- Advertiser
- Campaign
- Product
- Budget
- Start/end date
- Impressions
- Clicks
- Status

## Connectors
Dedicated Connect section with reusable framework for:
- YouTube
- TikTok
- Instagram
- Facebook
- X
- LinkedIn
- Google
- Discord
- Future services

Each connector supports:
- Logo
- Status
- Connect/disconnect
- Connected account
- Permissions
- Capabilities
- Last sync
- Error state

## Messages
Foundation for:
- Conversations
- Starting conversations
- Sending/receiving messages
- Notifications
Prepare for Supabase realtime.

## Search
Global search across:
- Users
- Posts
- Videos
- Livestreams
- Lessons
- Communities
- Products

## Notifications
Support notifications for:
- Comments
- Likes/reactions
- Followers
- Messages
- Community activity
- Livestreams
- Orders
- XP achievements
- Rank increases
- Unlocks
- Connector events

## Creator / Seller Studio
Management areas:
- Posts
- Videos
- Livestreams
- Products
- Communities
- Lessons where permitted
- Analytics
- Orders
- Ads

Clearly distinguish CREATE / MANAGE / VIEW.

## Supabase Data Architecture
Prepare relational models for:
users, profiles, ranks, xp_transactions, achievements, unlocks, lessons, lesson_questions, lesson_completions, posts, comments, reactions, communities, community_members, livestreams, livestream_viewers, products, product_images, carts, orders, order_items, connectors, notifications, messages, advertisements, campaigns.

Never expose secrets. Use environment variables.

## Security
- Protected routes
- Authentication-aware UI
- Authorization boundaries
- Input validation
- Safe errors
- Environment variables
- No exposed secrets
- Ownership checks
- Proper relationships

## UX
Every page needs:
- Loading
- Empty
- Error
- Success
- Mobile
- Desktop
- Keyboard accessibility
- Responsive navigation

Buttons must perform meaningful actions. Avoid decorative dead buttons.

## Demo Data
Populate realistic demo data for:
- Users
- Profiles
- Videos
- Live streams
- Lessons
- Communities
- Posts
- Products
- XP levels
- Achievements
- Connectors

Clearly separate demo/mock data from real backend data.

## Architecture
Use:
- Reusable components
- Cards
- Forms
- Modals
- Connector components
- XP components
- Product components
- Livestream components
- Feed components

Keep business logic separate from presentation and avoid unnecessary duplication.

## Quality Bar
OneMuslim must feel like a legitimate product combining modern social, video, learning, livestreaming, community, and marketplace experiences.

It must not feel like:
- School project
- Static HTML demo
- Generic dashboard template
- Disconnected pages
- AI-generated mockup

Long-term integration targets:
- Supabase Auth/database/storage/realtime
- OAuth connectors
- Stripe
- Real livestream infrastructure
- Notifications
- Real-time messaging

Prioritize functionality + beautiful design + scalability + consistency.
