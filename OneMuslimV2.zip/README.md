# OneMuslim

A production-ready foundation for a Muslim social, learning, livestreaming, community, and marketplace platform.

## Start

This first package is a frontend-first Next.js foundation designed to deploy cleanly to Vercel.

```bash
npm install
npm run dev
```

Then open the local URL shown by Next.js.

## Environment

Copy `.env.example` to `.env.local`.

Supabase is intentionally optional for the initial demo. When credentials are supplied, the app can transition toward real authentication/data services.

## Blueprint

See `BLUEPRINT.md`. This is the canonical product blueprint and should be preserved and consulted for future development.

## Demo

The demo sign-in accepts any non-empty email and password so the complete product experience can be explored before backend authentication is connected.

## Deployment

This project is designed for Vercel with Next.js.

```bash
npm run build
npm start
```
